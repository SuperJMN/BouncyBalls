﻿using System.Windows;

namespace Project1
{
    public class Circle
    {
        public Point Location { get; set; }
        public double Radius { get; set; }
        public Vector Velocity { get; set; }
    }
}